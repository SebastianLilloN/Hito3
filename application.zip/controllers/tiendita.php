<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tiendita extends CI_Controller {
		function __construct(){
			parent::__construct();
			$this->load->helper('form');
			$this->load->model('tiendita_model');
		}
		function index(){
			$data = array('titulo' => 'Home');
			$this->load->view('Guest/head', $data);
			$data = array('post' => 'Tiendita', 'descripcion' => 'Bienvenido');
			$this->load->view('Guest/header', $data);
			$data = array('app' => 'Tiendita');
			$this->load->view('Guest/nav', $data);
			$this->load->view('Guest/content');
			$this->load->view('Guest/footer');
		}
}
?>











