<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Productos extends CI_Controller {
		function __construct(){
			parent::__construct();
			$this->load->helper('form');
			$this->load->model('tiendita_model');
		}
		function modelos(){
			$data['segmento'] = $this->uri->segment(3);
			$this->load->view('Agregar/head');
			if(!$data['segmento']){
				$data['modelos'] = $this->tiendita_model->obtenerModelo();				
			}
			else{
				$data['modelos'] = $this->tiendita_model->obtenerModelos($data['segmento']);
			}
			$this->load->view('Agregar/nav');
			$this->load->view('Agregar/content',$data);
		}
		function recibirDatos(){
			$data = array(
				'modelo' => $this->input->post('modelo'),
				'serie' => $this->input->post('serie')
			);
			$this->tiendita_model->agregarModelo($data);
			$this->load->view('Productos/agregar');
		}
		function editar(){
			$data['id'] = $this->uri->segment(3);
			$data['modelo'] = $this->tiendita_model->obtenerModelo($data['id']);
			$this->load->view('Agregar/head');
			$this->load->view('Productos/editar', $data);
		}
		function actualizar(){
			$data = array(
				'modelo' => $this->input->post('modelo'),
				'serie' => $this->input->post('serie')
			);
			$this->tiendita_model->actualizarModelo($this->uri->segment(3), $data);
			$this->load->view('Agregar/head');
			$this->load->view('Productos/editar', $data);
		}
}

?>