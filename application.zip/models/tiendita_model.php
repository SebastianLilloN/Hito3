<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Tiendita_model extends CI_Model { 
	function __construct(){
		parent::__construct();
		$this->load->database();
	}
	function agregarModelo($data){
		$this->db->insert('modelos', array('nombreModelo'=>$data['modelo'], 'numeroSerie'=>$data['serie']));
	}
	function obtenerModelo(){
		$query = $this->db->get('modelos');
		if($query->num_rows() > 0) return $query;
		else return false;
	}
	function obtenerModelos($id){
		$this->db->where('idProducto', $id);	
		$query = $this->db->get('modelos');
		if($query->num_rows() > 0) return $query;
		else return false;
	}
	function actualizarModelo($id, $data){
		$datos = array(
			'nombreModelo'=>$data['modelo'], 
			'numeroSerie'=>$data['serie']
		);
		$this->db->where('idProducto', $id);
		$query = $this->db->update('modelos', $datos);
	}
}
?>