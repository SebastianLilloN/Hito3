<?= form_open("/Productos/actualizar/".$id) ?>
<?php
	$modelo = array(
		'name' => 'modelo',
		'placeholder' => 'Escribe el modelo',
		'value' => $modelo->result()[0]->nombreModelo
	);
	$serie = array(
		'name' => 'serie',
		'placeholder' => 'Número de serie',
		'value' => $modelo->result()[0]->numeroSerie
	);
?>
<?= form_label('Modelo: ', 'modelo')?>
<?= form_input($modelo)?>
<br>
<?= form_label('Numero de Serie: ', 'serie')?>
<?= form_input($serie)?>
<?= form_submit('', 'Actualizar Producto')?>
<?= form_close()?>

</body>
</html>
		