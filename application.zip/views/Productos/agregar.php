<?= form_open("/Productos/recibirDatos/") ?>
<?php
	$modelo = array(
		'name' => 'modelo',
		'placeholder' => 'Escribe el modelo'
	);
	$serie = array(
		'name' => 'serie',
		'placeholder' => 'Número de serie'
	);
?>
<?= form_label('Modelo: ', 'modelo')?>
<?= form_input($modelo)?>
<br>
<?= form_label('Numero de Serie: ', 'serie')?>
<?= form_input($serie)?>
<?= form_submit('', 'Subir modelo')?>
<?= form_close()?>

</body>
</html>
		