<?php
	if($modelos){
	foreach($modelos->result() as $modelo){ ?>
		<ul>
		<li><a href= "<?= $modelo->idProducto; ?>"><?= $modelo->nombreModelo; ?></a></li>
		</ul>
	<?php }
	}else{
		echo "<p>Error</p>";
	}
?>
</body>
</html>	