<!DOCTYPE html>
<html lang="es">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Tiendita - Start Bootstrap Template</title>
    <!-- Bootstrap core JavaScript -->
  <script src="<?= base_url()?>Plantilla/vendor/jquery/jquery.min.js"></script>
  <script src="<?= base_url()?>Plantilla/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Bootstrap core CSS -->
  <link href="<?= base_url()?>Plantilla/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="<?= base_url()?>Plantilla/css/shop-homepage.css" rel="stylesheet">

</head>
